from app import app

# This file is imported by gunicorn in the workflow